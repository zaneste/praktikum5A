<?php
class pdf {
    function __construct() {
        include_once APPATH. '/third_party/fpdf/fpdf.php';
    }
}
?>